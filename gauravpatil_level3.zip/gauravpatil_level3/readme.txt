convert the backdoor in to exe file format :
open windows terminal and type:-> pip install pyinstaller
->pyinstaller backdoor.py --onefile --noconsole
find the exe file into dist directory